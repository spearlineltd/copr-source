python zabbix api - https://github.com/gescheit/scripts/tree/master/zabbix

