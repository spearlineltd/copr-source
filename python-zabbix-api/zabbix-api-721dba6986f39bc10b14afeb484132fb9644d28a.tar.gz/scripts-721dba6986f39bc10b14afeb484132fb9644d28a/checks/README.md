functions.sh - functions for locking and caching  
disksmart.sh - check SMART of all disks in system
- Work under FreeBSD and linux
- Use caching and locking
