This tests are for code quality control, i.e. not required for acutal build.

Dependencies:
- perl5

Perl module dependencies:
- Exporter
- List::Util
- FindBin
- File::Path
