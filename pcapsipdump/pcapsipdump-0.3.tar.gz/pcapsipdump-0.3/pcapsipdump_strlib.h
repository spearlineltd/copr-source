#include <stdint.h>

uint8_t sdp_get_rtpmap_event(const char *sdp);

const char * gettag(const char *ptr, unsigned long len, const char *tag, unsigned long *gettaglen);

