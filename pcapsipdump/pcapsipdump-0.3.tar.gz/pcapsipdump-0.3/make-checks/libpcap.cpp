#include <pcap.h>
int main(void){pcap_set_snaplen((pcap_t *)NULL,100);return 0;}
