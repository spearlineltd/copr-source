#include <iostream>
int main(void){std::cout << "";}
